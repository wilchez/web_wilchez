<?php

$host="localhost";
$root="root";
$pass="";
$db="tallertres_bd";

$con=mysqli_connect($host,$root,$pass,$db) or die ("sebas no es posible conectarse a$host");

?>